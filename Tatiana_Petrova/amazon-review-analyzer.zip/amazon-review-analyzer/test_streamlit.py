import streamlit as st

st.title("Test Streamlit")
st.write("Hello, Streamlit works!")

if st.button("Click me"):
    st.write("Button clicked!")